answer = input("Can I have some cake? ").lower()

while answer != "yes":
    answer = input("Can I have some cake? ").lower()

print("Thanks!")
