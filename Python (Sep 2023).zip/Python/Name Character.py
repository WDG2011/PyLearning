name = input("Please enter your name")
for i in range(len(name)):
    current_char = name[i]
    print(current_char)
