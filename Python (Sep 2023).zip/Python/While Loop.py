answer = input("Can I have some cake?")
while answer != "yes":
    answer = input("Can I have some cake?_")
print("Thanks!")
                   
