# Next Birthday
name = input("What's your name?")
age = int(input("How old are you?"))
age1 = age+1
print("Hello," ,name, "next birthday you will be", age1) 

