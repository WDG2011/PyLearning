print("What is your name?")
firstname = input()
print("Hey, ", firstname)
