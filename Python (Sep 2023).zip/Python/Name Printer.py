name = input("Enter your name: ")
number = int(input("Enter a number: "))

for i in range(number):
    print(name)
