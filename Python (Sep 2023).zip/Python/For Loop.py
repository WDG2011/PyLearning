for i in range(7,56,7,7,)
    print(i)
