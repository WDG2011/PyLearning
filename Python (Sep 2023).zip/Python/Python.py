city = "new york"
print(city[0:3])
