from tkinter import *

def Call():
    user_name = entry.get()
    msg.config(text="Hello, " + user_name)
    msg.config(bg="blue", fg="white")

window = Tk()
window.geometry("200x110")

entry_label = Label(window, text="Enter your name:")
entry_label.place(x=30, y=20)

entry = Entry(window)
entry.place(x=30, y=40, width=120, height=25)

button = Button(text="Click me", command=Call)
button.place(x=30, y=70, width=120, height=25)

msg = Label(window, text="")
msg.place(x=30, y=100)

window.mainloop()
