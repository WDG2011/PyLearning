#Bill Split
total = int(input("Enter the amount that the total amount of the bill"))
people = int(input("How many people are you splitting the bill with?"))
each = total/ people
print("After dividing your total of", total, "by", people, "Each person must pay", each)
